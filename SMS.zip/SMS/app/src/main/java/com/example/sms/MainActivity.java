package com.example.sms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txtnum, txtmsg;
    Button btnsms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtnum = findViewById(R.id.txtnum);
        txtmsg = findViewById(R.id.txtmsg);
        btnsms = findViewById(R.id.btnsms);

        btnsms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    SmsManager smgr = SmsManager.getDefault();
                    smgr.sendTextMessage(txtnum.getText().toString(),
                            null, txtmsg.getText().toString(),
                            null, null);
                    Toast.makeText(MainActivity.this, "SMS Sent Successfully",
                            Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "SMS Failed to Send, " +
                            "Please try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
